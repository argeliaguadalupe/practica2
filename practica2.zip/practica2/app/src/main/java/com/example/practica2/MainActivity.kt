package com.example.practica2

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        var editTextpre = findViewById<EditText>(R.id.editTextText);
        var editTextdes = findViewById<EditText>(R.id.editTextText2);
        var resultado = findViewById<TextView>(R.id.textView2);
        var button = findViewById<Button>(R.id.button)
        var raiva = findViewById<RadioButton>(R.id.radioButton2);
        var siniva = findViewById<RadioButton>(R.id.radioButton3);

        button.setOnClickListener {
            var iva = 0.0;
            var precio = editTextpre.text.toString().toDoubleOrNull() ?: 0.0
            var descuento = editTextdes.text.toString().toDoubleOrNull() ?: 0.0
            var totalapa = precio - descuento

            if (raiva.isChecked) {
                iva = totalapa * 0.13
            }
            totalapa += iva
            resultado.text = "total a pagar es: $totalapa"
        }

    }
    }


















